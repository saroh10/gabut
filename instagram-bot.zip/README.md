# Bot Instagram

Bot Instagram dengan fitur scraping dan DM massal yang dilengkapi dengan fitur keamanan anti-deteksi.

## ✨ Fitur

### 🔍 Scraping
- Scrape followers dari username target
- Scrape username dari list DM
- Scrape username dari followers akun sendiri
- Fitur stop scraping (Ctrl+C)
- Setting jumlah scraping

### 💌 Kirim DM Massal
- Pilih file target hasil scraping
- Setting pesan
- Kirim pesan dengan delay random
- Log aktivitas pengiriman

### ⚙️ Pengaturan
- Setting delay random (min/max)
- Setting max jumlah DM per hari
- Toggle random delays
- Toggle anti-deteksi
- Statistik pengiriman DM

### 🛡️ Fitur Keamanan
- Random user agent
- Device rotation otomatis
- Anti deteksi sistem
- Delay random
- Penyimpanan session

## 📦 Instalasi

1. Pastikan Node.js sudah terinstall
2. Clone repository ini
3. Buka terminal di folder project
4. Install dependencies:
   ```bash
   npm install
   ```

## 🚀 Penggunaan

1. Jalankan bot:
   ```bash
   npm start
   ```

2. Login ke akun Instagram (hanya perlu sekali, session akan disimpan)
3. Pilih menu yang diinginkan
4. Ikuti instruksi di layar

## 📁 Struktur Folder

- `hasil/` - Menyimpan hasil scraping
- `config/` - File konfigurasi dan log
- `sessions/` - Menyimpan session login
- `src/` - Source code bot

## ⚠️ Perhatian

- Gunakan dengan bijak untuk menghindari pemblokiran akun
- Patuhi batas maksimal DM per hari
- Aktifkan fitur anti-deteksi untuk keamanan
- Jangan spam DM dalam jumlah besar dalam waktu singkat

## 📝 License

MIT
