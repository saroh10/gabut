const { IgApiClient } = require('instagram-private-api');
const inquirer = require('inquirer');
const chalk = require('chalk');
const figlet = require('figlet');
const fs = require('fs-extra');
const ora = require('ora');
const { handleLogin } = require('./src/auth');
const { handleScraping } = require('./src/scraping');
const { handleMessaging } = require('./src/messaging');
const { handleSettings } = require('./src/settings');

// Membuat folder yang diperlukan
['config', 'hasil', 'sessions'].forEach(dir => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
    }
});

async function showBanner() {
    console.clear();
    console.log(chalk.magenta(figlet.textSync('IG BOT', { horizontalLayout: 'full' })));
    console.log(chalk.cyan('✨ Bot Instagram - Dibuat dengan ❤️\n'));
}

async function mainMenu(ig) {
    const choices = [
        '1. 🔍 Scrape',
        '2. 💌 Kirim DM Massal', 
        '3. ⚙️ Pengaturan',
        '4. 🚪 Keluar'
    ];

    console.log('\n📋 Pilih Menu:');
    choices.forEach(choice => console.log(choice));

    const { action } = await inquirer.prompt([
        {
            type: 'input',
            name: 'action',
            message: 'Masukkan nomor menu (1-4):',
            validate: function(value) {
                const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= 4;
                return valid || 'Silakan masukkan nomor 1-4';
            }
        }
    ]);

    const menuChoice = parseInt(action);
    switch (menuChoice) {
        case 1:
            await handleScraping(ig);
            break;
        case 2:
            await handleMessaging(ig);
            break;
        case 3:
            await handleSettings();
            break;
        case 4:
            console.log(chalk.yellow('\n👋 Terima kasih telah menggunakan bot ini!\n'));
            process.exit(0);
    }

    await mainMenu(ig);
}

async function start() {
    try {
        await showBanner();
        
        // Inisialisasi Instagram API Client
        const ig = new IgApiClient();
        
        // Login atau gunakan session yang tersimpan
        await handleLogin(ig);
        
        // Tampilkan menu utama
        await mainMenu(ig);
    } catch (error) {
        console.error(chalk.red(`❌ Error: ${error.message}`));
        process.exit(1);
    }
}

// Menangani error yang tidak tertangkap
process.on('uncaughtException', (error) => {
    console.error(chalk.red('❌ Error tidak tertangkap:', error));
});

process.on('unhandledRejection', (error) => {
    console.error(chalk.red('❌ Promise rejection tidak tertangkap:', error));
});

start();
