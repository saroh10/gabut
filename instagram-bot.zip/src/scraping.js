const inquirer = require('inquirer');
const chalk = require('chalk');
const fs = require('fs-extra');
const ora = require('ora');
const moment = require('moment');

let stopScraping = false;

async function handleScraping(ig) {
    const choices = [
        '1. 👥 Scrape Followers dari Username Target',
        '2. 📩 Scrape Username dari List DM',
        '3. 🔄 Scrape Username dari Followers Sendiri',
        '4. ⬅️ Kembali ke Menu Utama'
    ];

    console.log('\n📋 Pilih Jenis Scraping:');
    choices.forEach(choice => console.log(choice));

    const { action } = await inquirer.prompt([
        {
            type: 'input',
            name: 'action',
            message: 'Masukkan nomor menu (1-4):',
            validate: function(value) {
                const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= 4;
                return valid || 'Silakan masukkan nomor 1-4';
            }
        }
    ]);

    if (parseInt(action) === 4) return;

    const { jumlahScrape } = await inquirer.prompt([
        {
            type: 'number',
            name: 'jumlahScrape',
            message: '📊 Masukkan jumlah data yang ingin di scrape:',
            default: 100,
            validate: value => value > 0 ? true : 'Jumlah harus lebih dari 0'
        }
    ]);

    // Reset flag stop
    stopScraping = false;

    // Tangani Ctrl+C untuk stop scraping
    process.on('SIGINT', () => {
        stopScraping = true;
        console.log(chalk.yellow('\n🛑 Menghentikan proses scraping...\n'));
    });

    try {
        let results = [];
        const timestamp = moment().format('YYYY-MM-DD_HH-mm-ss');
        
        switch(parseInt(action)) {
            case 1:
                results = await scrapeFollowers(ig, jumlahScrape);
                break;
            case 2:
                results = await scrapeDMList(ig, jumlahScrape);
                break;
            case 3:
                results = await scrapeOwnFollowers(ig, jumlahScrape);
                break;
        }

        if (results.length > 0) {
            // Simpan hasil dalam format JSON dan TXT
            const baseFileName = `./hasil/scrape_${timestamp}`;
            await fs.writeJSON(`${baseFileName}.json`, results);
            await fs.writeFile(`${baseFileName}.txt`, results.map(u => u.username).join('\n'));
            
            console.log(chalk.green(`\n✅ Berhasil menyimpan ${results.length} data ke:`));
            console.log(chalk.cyan(`📁 ${baseFileName}.json`));
            console.log(chalk.cyan(`📁 ${baseFileName}.txt`));
        }

    } catch (error) {
        console.error(chalk.red(`❌ Error: ${error.message}`));
    }
}

async function scrapeFollowers(ig, limit) {
    const { targetUsername } = await inquirer.prompt([
        {
            type: 'input',
            name: 'targetUsername',
            message: '👤 Masukkan username target:',
            validate: input => input.length > 0
        }
    ]);

    const spinner = ora('🔍 Mencari user...').start();
    const results = [];

    try {
        let targetUser;
        try {
            targetUser = await ig.user.searchExact(targetUsername);
        } catch (error) {
            if (error.response && error.response.body && error.response.body.challenge) {
                spinner.info('🔒 Instagram meminta verifikasi untuk pencarian...');
                
                // Tunggu beberapa detik sebelum mencoba lagi
                await new Promise(resolve => setTimeout(resolve, 5000));
                
                // Coba cara alternatif
                const searchResults = await ig.user.search(targetUsername);
                targetUser = searchResults.users.find(user => user.username === targetUsername);
                
                if (!targetUser) {
                    throw new Error('User tidak ditemukan');
                }
            } else {
                throw error;
            }
        }

        spinner.text = '📥 Mengambil data followers...';

        const followers = ig.feed.accountFollowers(targetUser.pk);
        let retryCount = 0;
        const maxRetries = 3;

        while (results.length < limit && !stopScraping) {
            try {
                const items = await followers.items();
                
                for (const user of items) {
                    if (stopScraping || results.length >= limit) break;
                    
                    results.push({
                        username: user.username,
                        fullName: user.full_name,
                        isPrivate: user.is_private,
                        timestamp: moment().format()
                    });

                    spinner.text = `📥 Mengambil data... ${results.length}/${limit}`;
                }

                if (!followers.isMoreAvailable()) break;
                
                // Reset retry counter setelah berhasil
                retryCount = 0;
                
                // Tambah delay random untuk menghindari deteksi
                await new Promise(resolve => setTimeout(resolve, Math.random() * 3000 + 2000));
                
            } catch (error) {
                if (error.response && error.response.body && error.response.body.challenge) {
                    if (retryCount >= maxRetries) {
                        throw new Error('Terlalu banyak permintaan verifikasi, coba lagi nanti');
                    }
                    
                    spinner.info('🔒 Instagram meminta verifikasi, menunggu sebentar...');
                    await new Promise(resolve => setTimeout(resolve, 10000 * (retryCount + 1)));
                    retryCount++;
                    continue;
                }
                throw error;
            }
        }

        spinner.succeed(`✅ Berhasil mengambil ${results.length} followers`);
        return results;

    } catch (error) {
        spinner.fail(`❌ Error: ${error.message}`);
        throw error;
    }
}

async function scrapeDMList(ig, limit) {
    const spinner = ora('📥 Mengambil data DM...').start();
    const results = [];

    try {
        const directInbox = ig.feed.directInbox();
        
        while (results.length < limit && !stopScraping) {
            const threads = await directInbox.items();
            
            for (const thread of threads) {
                if (stopScraping || results.length >= limit) break;
                
                const users = thread.users || [];
                for (const user of users) {
                    if (results.length >= limit) break;
                    
                    results.push({
                        username: user.username,
                        fullName: user.full_name,
                        isPrivate: user.is_private,
                        timestamp: moment().format()
                    });
                }

                spinner.text = `📥 Mengambil data... ${results.length}/${limit}`;
            }

            if (!directInbox.isMoreAvailable()) break;
        }

        spinner.succeed(`✅ Berhasil mengambil ${results.length} users dari DM`);
        return results;

    } catch (error) {
        spinner.fail(`❌ Error: ${error.message}`);
        throw error;
    }
}

async function scrapeOwnFollowers(ig, limit) {
    const spinner = ora('📥 Mengambil data followers...').start();
    const results = [];

    try {
        const followers = ig.feed.accountFollowers(ig.state.cookieUserId);
        
        while (results.length < limit && !stopScraping) {
            const items = await followers.items();
            
            for (const user of items) {
                if (stopScraping || results.length >= limit) break;
                
                results.push({
                    username: user.username,
                    fullName: user.full_name,
                    isPrivate: user.is_private,
                    timestamp: moment().format()
                });

                spinner.text = `📥 Mengambil data... ${results.length}/${limit}`;
            }

            if (!followers.isMoreAvailable()) break;
        }

        spinner.succeed(`✅ Berhasil mengambil ${results.length} followers`);
        return results;

    } catch (error) {
        spinner.fail(`❌ Error: ${error.message}`);
        throw error;
    }
}

module.exports = { handleScraping };
