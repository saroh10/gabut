const inquirer = require('inquirer');
const chalk = require('chalk');
const fs = require('fs-extra');
const ora = require('ora');
const randomUseragent = require('random-useragent');

const SESSION_FILE = './sessions/session.json';

const devices = [
    { name: 'Samsung Galaxy S21', android_version: '12', dpi: '640dpi', resolution: '1440x3200', manufacturer: 'samsung', device: 'SM-G991B', model: 'SM-G991B', cpu: 'exynos2100' },
    { name: 'Google Pixel 6', android_version: '12', dpi: '420dpi', resolution: '1080x2400', manufacturer: 'google', device: 'oriole', model: 'Pixel 6', cpu: 'gs101' },
    { name: 'OnePlus 9', android_version: '11', dpi: '420dpi', resolution: '1080x2400', manufacturer: 'oneplus', device: 'OnePlus9', model: 'OnePlus 9', cpu: 'lahaina' }
];

function getRandomDevice() {
    return devices[Math.floor(Math.random() * devices.length)];
}

function getRandomUserAgent() {
    return randomUseragent.getRandom(ua => {
        return ua.deviceType === 'mobile' && 
               (ua.browserName === 'Chrome' || ua.browserName === 'Firefox');
    });
}

async function setupSecurityMeasures(ig) {
    const device = getRandomDevice();
    const userAgent = getRandomUserAgent();

    // Set device dan user agent
    ig.state.deviceString = `${device.manufacturer}_${device.model}`;
    ig.state.deviceId = `android-${Math.random().toString(16).slice(2, 10)}`;
    ig.state.phoneId = `${Math.random().toString(16).slice(2, 18)}`;
    ig.state.adid = `${Math.random().toString(16).slice(2, 18)}`;
    ig.state.build = device.android_version;
    ig.state.userAgent = userAgent;

    return ig;
}

async function handleLogin(ig) {
    try {
        // Cek apakah ada session tersimpan
        if (await fs.pathExists(SESSION_FILE)) {
            const spinner = ora('📱 Mencoba menggunakan session tersimpan...').start();
            try {
                const session = await fs.readJSON(SESSION_FILE);
                await ig.state.deserialize(session);
                await ig.user.info(ig.state.cookieUserId);
                spinner.succeed('✅ Berhasil masuk menggunakan session tersimpan!');
                return;
            } catch (error) {
                spinner.fail('❌ Session tidak valid, diperlukan login ulang');
                await fs.remove(SESSION_FILE);
            }
        }

        // Setup keamanan sebelum login
        await setupSecurityMeasures(ig);

        // Login baru
        const { username, password } = await inquirer.prompt([
            {
                type: 'input',
                name: 'username',
                message: '👤 Masukkan username Instagram:',
                validate: input => input.length > 0
            },
            {
                type: 'password',
                name: 'password',
                message: '🔑 Masukkan password:',
                mask: '*',
                validate: input => input.length > 0
            }
        ]);

        const spinner = ora('🔄 Sedang login...').start();

        try {
            // Generate device ID sebelum login
            ig.state.generateDevice(username);
            
            // Proses login dengan penanganan challenge
            try {
                const auth = await ig.account.login(username, password);
                
                // Simpan session
                const serialized = await ig.state.serialize();
                await fs.writeJSON(SESSION_FILE, serialized);
                
                spinner.succeed('✅ Login berhasil dan session tersimpan!');
            } catch (error) {
                if (error.response && error.response.body && error.response.body.challenge) {
                    // Handle challenge required
                    spinner.info('🔒 Instagram meminta verifikasi tambahan...');
                    await handleChallenge(ig, error.response.body.challenge);
                    
                    // Setelah challenge berhasil, simpan session
                    const serialized = await ig.state.serialize();
                    await fs.writeJSON(SESSION_FILE, serialized);
                    
                    spinner.succeed('✅ Verifikasi berhasil dan session tersimpan!');
                } else {
                    throw error;
                }
            }
        } catch (error) {
            spinner.fail(`❌ Gagal login: ${error.message}`);
            throw error;
        }
    } catch (error) {
        console.error(chalk.red(`❌ Error dalam proses login: ${error.message}`));
        process.exit(1);
    }
}

async function handleChallenge(ig, challenge) {
    try {
        // Dapatkan informasi challenge
        await ig.challenge.auto(challenge.api_path);
        
        // Tanyakan kode verifikasi
        const { verificationCode } = await inquirer.prompt([
            {
                type: 'input',
                name: 'verificationCode',
                message: '🔑 Masukkan kode verifikasi yang dikirim ke email/nomor telepon:',
                validate: input => /^\d{6}$/.test(input) ? true : 'Kode harus 6 digit angka'
            }
        ]);

        // Kirim kode verifikasi
        const verifyResult = await ig.challenge.sendSecurityCode(verificationCode);
        
        if (!verifyResult.logged_in_user) {
            throw new Error('Kode verifikasi tidak valid');
        }
        
        return verifyResult;
    } catch (error) {
        throw new Error(`Gagal verifikasi: ${error.message}`);
    }
}

module.exports = { handleLogin };
