const inquirer = require('inquirer');
const chalk = require('chalk');
const fs = require('fs-extra');
const ora = require('ora');
const { getSettings } = require('./settings');

async function handleMessaging(ig) {
    const choices = [
        '1. 📁 Pilih File Target',
        '2. ✏️ Setting Pesan',
        '3. 📨 Mulai Kirim Pesan',
        '4. ⬅️ Kembali ke Menu Utama'
    ];

    console.log('\n📋 Menu DM Massal:');
    choices.forEach(choice => console.log(choice));

    const { action } = await inquirer.prompt([
        {
            type: 'input',
            name: 'action',
            message: 'Masukkan nomor menu (1-4):',
            validate: function(value) {
                const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= 4;
                return valid || 'Silakan masukkan nomor 1-4';
            }
        }
    ]);

    if (parseInt(action) === 4) return;

    try {
        switch (parseInt(action)) {
            case 1:
                await selectTargetFile();
                break;
            case 2:
                await setMessage();
                break;
            case 3:
                await startSendingMessages(ig);
                break;
        }
    } catch (error) {
        console.error(chalk.red(`❌ Error: ${error.message}`));
    }

    // Kembali ke menu messaging
    await handleMessaging(ig);
}

async function selectTargetFile() {
    // Baca semua file di folder hasil
    const files = await fs.readdir('./hasil');
    const txtFiles = files.filter(file => file.endsWith('.txt'));

    if (txtFiles.length === 0) {
        console.log(chalk.yellow('⚠️ Tidak ada file hasil scraping (.txt) yang ditemukan!'));
        return;
    }

    console.log('\n📂 Pilih file target (.txt):');
    txtFiles.forEach((file, index) => {
        console.log(`${index + 1}. ${file}`);
    });

    const { selectedIndex } = await inquirer.prompt([
        {
            type: 'input',
            name: 'selectedIndex',
            message: `Masukkan nomor file (1-${txtFiles.length}):`,
            validate: function(value) {
                const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= txtFiles.length;
                return valid || `Silakan masukkan nomor 1-${txtFiles.length}`;
            }
        }
    ]);

    const selectedFile = txtFiles[parseInt(selectedIndex) - 1];

    // Simpan pilihan file ke settings
    await fs.writeJSON('./config/dm_settings.json', { targetFile: selectedFile });
    console.log(chalk.green(`✅ File target berhasil dipilih: ${selectedFile}`));
}

async function setMessage() {
    console.log('\n✏️ Setting Pesan:');
    const choices = [
        '1. Buat Pesan Baru',
        '2. Pilih Pesan yang Sudah Ada',
        '3. Kembali'
    ];
    
    choices.forEach(choice => console.log(choice));

    const { action } = await inquirer.prompt([
        {
            type: 'input',
            name: 'action',
            message: 'Masukkan nomor menu (1-3):',
            validate: function(value) {
                const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= 3;
                return valid || 'Silakan masukkan nomor 1-3';
            }
        }
    ]);

    const actionNumber = parseInt(action);
    if (actionNumber === 3) return;

    if (actionNumber === 1) {
        let currentMessage = '';
        try {
            const settings = await fs.readJSON('./config/dm_settings.json');
            currentMessage = settings.message || '';
        } catch (error) {
            // Ignore if file doesn't exist
        }

        const questions = [
            {
                type: 'input',
                name: 'message',
                message: '✍️ Ketik pesan:',
                default: currentMessage
            },
            {
                type: 'input',
                name: 'filename',
                message: '💾 Masukkan nama file untuk menyimpan pesan (tanpa .txt):',
                validate: input => input.length > 0 || 'Nama file tidak boleh kosong'
            }
        ];

        const answers = await inquirer.prompt(questions);

        // Simpan ke settings dengan mempertahankan targetFile yang sudah ada
        const currentSettings = await fs.readJSON('./config/dm_settings.json').catch(() => ({}));
        await fs.writeJSON('./config/dm_settings.json', { 
            ...currentSettings,
            message: answers.message 
        });

        // Simpan ke file di folder pesan
        const filename = `${answers.filename}.txt`;
        await fs.writeFile(`./pesan/${filename}`, answers.message);

        console.log(chalk.green(`✅ Pesan berhasil disimpan ke file: ${filename}`));
    } else if (actionNumber === 2) {
        // Baca semua file di folder pesan
        const files = await fs.readdir('./pesan');
        const txtFiles = files.filter(file => file.endsWith('.txt'));

        if (txtFiles.length === 0) {
            console.log(chalk.yellow('⚠️ Tidak ada file pesan yang tersimpan!'));
            return;
        }

        console.log('\n📂 Pilih file pesan:');
        txtFiles.forEach((file, index) => {
            console.log(`${index + 1}. ${file}`);
        });

        const { selectedIndex } = await inquirer.prompt([
            {
                type: 'input',
                name: 'selectedIndex',
                message: `Masukkan nomor file (1-${txtFiles.length}):`,
                validate: function(value) {
                    const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= txtFiles.length;
                    return valid || `Silakan masukkan nomor 1-${txtFiles.length}`;
                }
            }
        ]);

        const selectedFile = txtFiles[parseInt(selectedIndex) - 1];

        // Baca isi file
        const message = await fs.readFile(`./pesan/${selectedFile}`, 'utf8');

        // Simpan ke settings dengan mempertahankan targetFile yang sudah ada
        const currentSettings = await fs.readJSON('./config/dm_settings.json').catch(() => ({}));
        await fs.writeJSON('./config/dm_settings.json', { 
            ...currentSettings,
            message 
        });

        console.log(chalk.green(`✅ Pesan dari file ${selectedFile} berhasil dimuat!`));
    }
}

async function startSendingMessages(ig) {
    try {
        // Baca settings
        const dmSettings = await fs.readJSON('./config/dm_settings.json').catch(() => ({}));
        const settings = await getSettings();

        if (!dmSettings.targetFile || !dmSettings.message) {
            console.log(chalk.yellow('⚠️ Harap pilih file target dan set pesan terlebih dahulu!'));
            return;
        }

        // Baca file target
        const targets = await fs.readFile(`./hasil/${dmSettings.targetFile}`, 'utf8');
        const usernames = targets.split('\n')
            .filter(username => username.trim())
            .map(username => username.trim());

        // Baca history pengiriman untuk skip yang sudah berhasil
        const sentHistory = await loadSentHistory();
        const remainingUsers = usernames.filter(username => !sentHistory.includes(username));

        if (remainingUsers.length === 0) {
            console.log(chalk.yellow('⚠️ Semua pesan sudah terkirim ke target yang dipilih!'));
            return;
        }

        const spinner = ora('Memulai pengiriman pesan...').start();

        let sentCount = 0;
        let failedCount = 0;
        let retryCount = 0;
        const maxDailyDM = settings.maxDailyDM || 50;
        const maxRetries = 5; // Meningkatkan jumlah retry
        const startTime = Date.now();

        console.log(chalk.cyan('\n📊 Status Pengiriman:'));
        console.log(chalk.white('─'.repeat(50)));
        console.log(chalk.blue(`📝 Total Target: ${remainingUsers.length}`));
        console.log(chalk.yellow(`⚠️ Batas DM per hari: ${maxDailyDM}`));
        console.log(chalk.white('─'.repeat(50)));

        for (const username of remainingUsers) {
            if (sentCount >= maxDailyDM) {
                console.log(chalk.yellow(`\n⚠️ Batas maksimal DM harian (${maxDailyDM}) tercapai!`));
                break;
            }

            let success = false;
            retryCount = 0;

            while (!success && retryCount < maxRetries) {
                try {
                    // Random delay antara setiap pesan
                    const delay = Math.floor(Math.random() * 
                        (settings.maxDelay - settings.minDelay + 1) + settings.minDelay);
                    
                    spinner.text = `⏳ Menunggu delay ${(delay/1000).toFixed(1)} detik sebelum mengirim ke ${username}...`;
                    await new Promise(resolve => setTimeout(resolve, delay));

                    // Coba beberapa metode pengiriman
                    try {
                        // Metode 1: Direct Thread
                        const thread = await ig.entity.directThread([username]);
                        await thread.broadcastText(dmSettings.message);
                    } catch (error) {
                        // Metode 2: Coba dengan user ID
                        const user = await ig.user.searchExact(username);
                        const thread = ig.entity.directThread([user.pk.toString()]);
                        await thread.broadcastText(dmSettings.message);
                    }

                    sentCount++;
                    success = true;
                    
                    // Simpan ke history
                    await addToSentHistory(username);
                    
                    console.log(chalk.green(`✅ Berhasil mengirim ke ${username} [${sentCount}/${Math.min(remainingUsers.length, maxDailyDM)}]`));

                    // Log aktivitas
                    await logActivity(username, true);

                    // Update progress
                    const progress = (sentCount / Math.min(remainingUsers.length, maxDailyDM)) * 100;
                    spinner.text = `📨 Progress: ${progress.toFixed(1)}% | Berhasil: ${sentCount} | Gagal: ${failedCount}`;

                    // Reset retry counter setelah berhasil
                    retryCount = 0;

                } catch (error) {
                    const errorMessage = error.message || 'Unknown error';

                    // Handle connection reset error
                    if (errorMessage.includes('ECONNRESET') || 
                        errorMessage.includes('network') || 
                        errorMessage.includes('timeout')) {
                        retryCount++;
                        const waitTime = 15000 * retryCount; // Meningkatkan waktu tunggu
                        console.log(chalk.yellow(`⚠️ Masalah koneksi, mencoba ulang (${retryCount}/${maxRetries}) dalam ${waitTime/1000} detik...`));
                        await new Promise(resolve => setTimeout(resolve, waitTime));
                        continue;
                    }

                    // Handle spam/block error
                    if (errorMessage.includes('spam') || errorMessage.includes('block')) {
                        const waitTime = 600000; // 10 menit
                        console.log(chalk.yellow(`⚠️ Terdeteksi spam/block, menunggu ${waitTime/1000/60} menit...`));
                        await new Promise(resolve => setTimeout(resolve, waitTime));
                        retryCount++;
                        continue;
                    }

                    // Handle rate limit
                    if (errorMessage.includes('rate') || errorMessage.includes('limit')) {
                        const waitTime = 900000; // 15 menit
                        console.log(chalk.yellow(`⚠️ Rate limit, menunggu ${waitTime/1000/60} menit...`));
                        await new Promise(resolve => setTimeout(resolve, waitTime));
                        retryCount++;
                        continue;
                    }

                    if (retryCount >= maxRetries) {
                        failedCount++;
                        console.log(chalk.red(`❌ Gagal mengirim ke ${username} setelah ${maxRetries} percobaan: ${errorMessage}`));
                        await logActivity(username, false, errorMessage);
                        // Simpan username yang gagal untuk dicoba lagi nanti
                        await addToFailedList(username, errorMessage);
                    } else {
                        retryCount++;
                        const waitTime = 8000 * retryCount;
                        console.log(chalk.yellow(`⚠️ Gagal mengirim, mencoba ulang (${retryCount}/${maxRetries}) dalam ${waitTime/1000} detik...`));
                        await new Promise(resolve => setTimeout(resolve, waitTime));
                        continue;
                    }
                    break;
                }
            }

            // Jika sudah mengirim beberapa pesan, tunggu sebentar
            if (sentCount > 0 && sentCount % 5 === 0) {
                const cooldownTime = 30000; // 30 detik setiap 5 pesan
                console.log(chalk.blue(`\n⏳ Cooldown ${cooldownTime/1000} detik untuk keamanan...\n`));
                await new Promise(resolve => setTimeout(resolve, cooldownTime));
            }
        }

        const duration = Math.floor((Date.now() - startTime) / 1000);
        console.log(chalk.white('\n─'.repeat(50)));
        console.log(chalk.cyan('📊 Ringkasan Pengiriman:'));
        console.log(chalk.green(`✅ Berhasil: ${sentCount} pesan`));
        console.log(chalk.red(`❌ Gagal: ${failedCount} pesan`));
        console.log(chalk.blue(`⏱️ Waktu: ${Math.floor(duration/60)} menit ${duration%60} detik`));
        console.log(chalk.yellow(`📝 Sisa target: ${remainingUsers.length - sentCount}`));
        console.log(chalk.white('─'.repeat(50)));

        if (failedCount > 0) {
            console.log(chalk.yellow('\n⚠️ Beberapa pesan gagal terkirim. Lihat failed_messages.json untuk detail.'));
        }

        spinner.succeed(chalk.green('✨ Proses pengiriman selesai!'));

    } catch (error) {
        console.error(chalk.red(`\n❌ Error: ${error.message}`));
    }
}

async function loadSentHistory() {
    try {
        const history = await fs.readJSON('./config/sent_history.json').catch(() => ([]));
        return history;
    } catch (error) {
        return [];
    }
}

async function addToSentHistory(username) {
    try {
        const history = await loadSentHistory();
        if (!history.includes(username)) {
            history.push(username);
            await fs.writeJSON('./config/sent_history.json', history);
        }
    } catch (error) {
        console.error('Error menyimpan history:', error);
    }
}

async function addToFailedList(username, error) {
    try {
        const failedList = await fs.readJSON('./config/failed_messages.json').catch(() => ([]));
        failedList.push({
            username,
            error,
            timestamp: new Date().toISOString()
        });
        await fs.writeJSON('./config/failed_messages.json', failedList, { spaces: 2 });
    } catch (error) {
        console.error('Error menyimpan failed list:', error);
    }
}

async function logActivity(username, success, errorMessage = '') {
    const logEntry = {
        timestamp: new Date().toISOString(),
        username,
        success,
        errorMessage,
        messageStatus: success ? 'Terkirim' : 'Gagal'
    };

    // Simpan log ke file
    const logFile = './config/dm_log.json';
    const logs = await fs.readJSON(logFile).catch(() => []);
    logs.push(logEntry);
    await fs.writeJSON(logFile, logs, { spaces: 2 });
}

module.exports = { handleMessaging };
