const inquirer = require('inquirer');
const chalk = require('chalk');
const fs = require('fs-extra');

const SETTINGS_FILE = './config/settings.json';

const defaultSettings = {
    minDelay: 30000,  // 30 detik
    maxDelay: 60000,  // 60 detik
    maxDailyDM: 50,
    useRandomDelay: true,
    useAntiDetection: true
};

async function handleSettings() {
    // Pastikan settings file ada
    await initSettings();

    const settings = await getSettings();
    
    const choices = [
        `1. ⏱️ Setting Delay (${settings.minDelay/1000}s - ${settings.maxDelay/1000}s)`,
        `2. 📊 Max DM per Hari (${settings.maxDailyDM})`,
        `3. 🎲 Random Delay (${settings.useRandomDelay ? 'ON' : 'OFF'})`,
        `4. 🛡️ Anti Deteksi (${settings.useAntiDetection ? 'ON' : 'OFF'})`,
        '5. 📊 Lihat Statistik DM',
        '6. ⬅️ Kembali ke Menu Utama'
    ];

    console.log('\n⚙️ Menu Pengaturan:');
    choices.forEach(choice => console.log(choice));

    const { action } = await inquirer.prompt([
        {
            type: 'input',
            name: 'action',
            message: 'Masukkan nomor menu (1-6):',
            validate: function(value) {
                const valid = !isNaN(value) && parseInt(value) >= 1 && parseInt(value) <= 6;
                return valid || 'Silakan masukkan nomor 1-6';
            }
        }
    ]);

    if (parseInt(action) === 6) return;

    try {
        switch (parseInt(action)) {
            case 1:
                await setDelaySettings();
                break;
            case 2:
                await setMaxDailyDM();
                break;
            case 3:
                await toggleRandomDelay();
                break;
            case 4:
                await toggleAntiDetection();
                break;
            case 5:
                await showStatistics();
                break;
        }
    } catch (error) {
        console.error(chalk.red(`❌ Error: ${error.message}`));
    }

    // Kembali ke menu settings
    await handleSettings();
}

async function initSettings() {
    if (!await fs.pathExists(SETTINGS_FILE)) {
        await fs.writeJSON(SETTINGS_FILE, defaultSettings);
    }
}

async function getSettings() {
    await initSettings();
    return await fs.readJSON(SETTINGS_FILE);
}

async function updateSettings(newSettings) {
    const currentSettings = await getSettings();
    await fs.writeJSON(SETTINGS_FILE, { ...currentSettings, ...newSettings });
}

async function setDelaySettings() {
    const { minDelay, maxDelay } = await inquirer.prompt([
        {
            type: 'number',
            name: 'minDelay',
            message: '⏱️ Masukkan delay minimal (dalam detik):',
            default: 30,
            validate: value => value >= 10 ? true : 'Delay minimal harus 10 detik atau lebih'
        },
        {
            type: 'number',
            name: 'maxDelay',
            message: '⏱️ Masukkan delay maksimal (dalam detik):',
            default: 60,
            validate: (value, answers) => value >= answers.minDelay ? true : 'Delay maksimal harus lebih besar dari delay minimal'
        }
    ]);

    await updateSettings({
        minDelay: minDelay * 1000,
        maxDelay: maxDelay * 1000
    });

    console.log(chalk.green('✅ Setting delay berhasil diperbarui!'));
}

async function setMaxDailyDM() {
    const { maxDailyDM } = await inquirer.prompt([
        {
            type: 'number',
            name: 'maxDailyDM',
            message: '📊 Masukkan batas maksimal DM per hari:',
            default: 50,
            validate: value => value > 0 && value <= 100 ? true : 'Batas harus antara 1-100'
        }
    ]);

    await updateSettings({ maxDailyDM });
    console.log(chalk.green('✅ Batas maksimal DM berhasil diperbarui!'));
}

async function toggleRandomDelay() {
    const settings = await getSettings();
    await updateSettings({ useRandomDelay: !settings.useRandomDelay });
    console.log(chalk.green(`✅ Random Delay: ${!settings.useRandomDelay ? 'ON' : 'OFF'}`));
}

async function toggleAntiDetection() {
    const settings = await getSettings();
    await updateSettings({ useAntiDetection: !settings.useAntiDetection });
    console.log(chalk.green(`✅ Anti Deteksi: ${!settings.useAntiDetection ? 'ON' : 'OFF'}`));
}

async function showStatistics() {
    try {
        const logFile = './config/dm_log.json';
        if (!await fs.pathExists(logFile)) {
            console.log(chalk.yellow('⚠️ Belum ada data statistik'));
            return;
        }

        const logs = (await fs.readFile(logFile, 'utf8'))
            .split('\n')
            .filter(line => line.trim())
            .map(line => JSON.parse(line));

        const totalDM = logs.length;
        const successDM = logs.filter(log => log.success).length;
        const failedDM = totalDM - successDM;
        const successRate = ((successDM / totalDM) * 100).toFixed(2);

        console.log(chalk.cyan('\n📊 Statistik Pengiriman DM:'));
        console.log(chalk.white(`Total DM: ${totalDM}`));
        console.log(chalk.green(`Berhasil: ${successDM}`));
        console.log(chalk.red(`Gagal: ${failedDM}`));
        console.log(chalk.yellow(`Success Rate: ${successRate}%\n`));

    } catch (error) {
        console.error(chalk.red('❌ Gagal membaca statistik:', error.message));
    }
}

module.exports = { handleSettings, getSettings, updateSettings };
